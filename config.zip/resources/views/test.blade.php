<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="viewport" content="width=21cm, initial-scale=1">
    <title>Document</title>
    <style>
        body{
            width: 21cm;
            padding: 5cm;
            margin: auto;
            border: 1px #D3D3D3 solid;
            border-radius: 5px;
            background: white;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
            clear: both;
        }
        .Cetak{
            
        }
        *{
            box-sizing: border-box;
        }
    </style>
</head>
<body>
    <div class="container-fluid cetak">
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam repudiandae at ad iste sed natus rerum quisquam error debitis vero accusamus tenetur illo itaque, commodi voluptatem? Necessitatibus saepe temporibus aut.</p>
    </div>
</body>
</html>