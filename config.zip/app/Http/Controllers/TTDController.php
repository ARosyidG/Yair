<?php

namespace App\Http\Controllers;

use App\Models\TTD;
use App\Http\Requests\StoreTTDRequest;
use App\Http\Requests\UpdateTTDRequest;

class TTDController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreTTDRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(TTD $tTD)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(TTD $tTD)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateTTDRequest $request, TTD $tTD)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(TTD $tTD)
    {
        //
    }
}
