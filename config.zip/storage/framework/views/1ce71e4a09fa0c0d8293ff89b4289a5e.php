

<?php $__env->startSection('Content'); ?>
<main class="container-fluid mt-5 mb-3">
    <div class="" style="width: 100%; text-align:center" >
        <p><h1 style="font-size: 200px">YAIR</h1></p>
        <p><h2>Website Pengelolaan Surat YAYASAN AMAL IKHLAS AL-RIDWANI</h2></p>
        <a href="/Surat"><button class="btn btn-success">Login</button></a>
    </div>
    
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("Layout.Navbar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project and College\WEB\TestingLaravel\Yair\resources\views/Home.blade.php ENDPATH**/ ?>