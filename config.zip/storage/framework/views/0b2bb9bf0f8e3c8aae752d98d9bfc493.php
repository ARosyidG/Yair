
<?php $__env->startSection("Content"); ?>
<ul class="list-group list-group flex-column mb-auto mt-3">
    <li class="list-group-item p-1 bg-success text-white">Surat</li>
    <li id="Berita" class="list-group-item p-1 px-3"  >
        <table class="table table-striped table-bordered w-auto">
            <thead>
            <tr>
                <th scope="col">Index</th>
                <th scope="col">Nomor Surat</th>
                <th scope="col">Subjek</th>
                <th scope="col">Status</th>
                <th scope="col"></th>
            </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $SignSurat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sign): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <tr>
                    <td><?php echo e($sign->Surat->id); ?></td>
                    <td><?php echo e($sign->Surat->NomorSurat); ?></td>
                    <td><?php echo e($sign->Surat->Subjek); ?></td>
                    <td><?php echo e($sign->Sign); ?></td>
                    <td>
                        <a href="/Surat/Sign/<?php echo e($sign->id); ?>"><button>Sign</button></a>
                        <a href="/Preview/<?php echo e($sign->Surat->id); ?>"><button>Preview</button></a>
                    </td>
                    
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </li>
</ul>
<?php if(Auth::user()->Jabatan == "admin"): ?>
    <a href="/Surat/create"><button class="btn btn-success">Tambah Surat</button></a>
    <ul class="list-group list-group flex-column mb-auto mt-3">
        <li class="list-group-item p-1 bg-warning text-white">Surat</li>
        <li id="Berita" class="list-group-item p-1 px-3"  >
            <table class="table table-striped table-bordered w-auto">
                <thead>
                <tr>
                    <th scope="col">Index</th>
                    <th scope="col">Nomor Surat</th>
                    <th scope="col">Subjek</th>
                    <th scope="col"></th>
                </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $Surat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($s->id); ?></td>
                            <td><?php echo e($s->NomorSurat); ?></td>
                            <td><?php echo e($s->Subjek); ?></td>
                            <td>
                                <button>Hapus</button>
                                <a href="/Surat/<?php echo e($s->id); ?>/edit"><button>Edit</button></a>
                                <a href="/Preview/<?php echo e($s->id); ?>"><button>Preview</button></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </li>
    </ul>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("Layout.SideBar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project and College\WEB\TestingLaravel\Yair\resources\views/Surat.blade.php ENDPATH**/ ?>