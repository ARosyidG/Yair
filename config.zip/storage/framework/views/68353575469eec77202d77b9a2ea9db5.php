
<?php $__env->startSection('Content'); ?>
<ul class="list-group list-group flex-column mb-auto mt-3">
    <li class="list-group-item p-1 bg-success text-white">Biodata</li>
    <li id="Berita" class="list-group-item p-1 px-3">
        <form action="/Anggota/<?php echo e($Anggota->id); ?>" method="POST" enctype="multipart/form-data">
            <?php echo method_field('put'); ?>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="exampleInputPassword1">Nama:</label>
                <input type="text" name="Nama" class="form-control" id="exampleInputPassword1" placeholder="Nama" value="<?php echo e($Anggota->Nama); ?>">
            </div>
            <div class="form-group">
                <label for="exampleInputPassword1">Jabatan:</label>
                <?php if(Auth::user()->Jabatan == "admin"): ?>
                    <input type="text" name="Jabatan" class="form-control" id="exampleInputPassword1" placeholder="Nama" value="<?php echo e($Anggota->Jabatan); ?>">
                <?php else: ?>
                    <input type="hidden" name="Jabatan" class="form-control"  id="exampleInputPassword1" placeholder="Nama" value="<?php echo e($Anggota->Jabatan); ?>">
                    <div><?php echo e($Anggota->Jabatan); ?></div>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="exampleInputPassword1">Username:</label>
                <?php if($Anggota->username == null): ?>
                <input type="text" name="username" class="form-control" id="exampleInputPassword1" placeholder="username" value="">
                <?php else: ?>
                <input type="text" name="username" class="form-control" id="exampleInputPassword1" placeholder="username" value=<?php echo e($Anggota->username); ?>>
                <?php endif; ?>
                    
            </div>
            <div class="form-group">
                <label for="exampleInputPassword1">Password:</label>
                <?php if($Anggota->password == null): ?>
                <input type="text" name="password" class="form-control" id="exampleInputPassword1" placeholder="password">
                <?php else: ?>
                <input type="text" name="password" class="form-control" id="exampleInputPassword1" placeholder="password" >
                <?php endif; ?>
                    
            </div>
            <div class="form-group mt-3">
                <div>
                    <label for="Gambar">Gambar</label>
                </div>
                <div>
                    <?php if($Anggota->TTD== null): ?>
                        <img class="border rounded p-2" src="" alt="" id="imgPre" class="mt-3" style="height:100px; width:auto;">
                    <?php else: ?>
                    <img class="border rounded p-2" src="/<?php echo e($Anggota->TTD->Gambar); ?>" alt="" id="imgPre" class="mt-3" style="height:100px; width:auto;">
                        <?php endif; ?>
                </div>
                <input type="file" class="form-control" id="Gambar" name="Gambar" onchange="imgPreview()">
            </div>
            <button class="btn btn-success" type="submit">Apply</button>
        </form>
    </li>
    </ul>
    <script src="/js/Biodata.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout.SideBar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project and College\WEB\TestingLaravel\Yair\resources\views/Biodata.blade.php ENDPATH**/ ?>