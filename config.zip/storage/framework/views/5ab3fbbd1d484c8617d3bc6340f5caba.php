
<?php $__env->startSection('Content'); ?>
<a href="/Anggota/create"><button class="btn btn-success">Tambah Anggota</button></a>
<ul class="list-group list-group flex-column mb-auto mt-3">
    <li class="list-group-item p-1 bg-success text-white">Surat</li>
    <li id="Berita" class="list-group-item p-1 px-3"  >
        <table class="table table-striped table-bordered ">
            <thead>
            <tr>
                <th scope="col">Nama</th>
                <th scope="col">Jabatan</th>
                <th scope="col">Control Menu</th>
                <th scope="col"></th>
            </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $Anggotas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Anggota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($Anggota->Nama); ?></td>
                    <td><?php echo e($Anggota->Jabatan); ?></td>
                    <td>
                        <button>Hapus</button>
                        <a href="/Anggota/<?php echo e($Anggota->id); ?>/edit"><button>Edit</button></a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </li>
    </ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout.SideBar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project and College\WEB\TestingLaravel\Yair\resources\views/Anggota.blade.php ENDPATH**/ ?>